/**
 * Service Worker — background.js
 * Handles tab updates, proxies API requests, and manages auth tokens.
 */

// ── JobDetector (inlined — cannot use ES module imports in MV3 service worker) ─

class JobDetector {
  /**
   * @param {string} url
   * @returns {{ detected: boolean, platform: string | null }}
   */
  detect(url) {
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return { detected: false, platform: null };
    }

    const { hostname, pathname, search } = parsed;

    // LinkedIn: linkedin.com + /jobs/view/ in path
    if (hostname.includes('linkedin.com') && pathname.includes('/jobs/view/')) {
      return { detected: true, platform: 'linkedin' };
    }

    // Indeed: indeed.com + /viewjob in path or search
    if (hostname.includes('indeed.com') && (pathname.includes('/viewjob') || search.includes('/viewjob'))) {
      return { detected: true, platform: 'indeed' };
    }

    // Greenhouse: boards.greenhouse.io + /*/jobs/* path pattern
    if (hostname === 'boards.greenhouse.io') {
      const parts = pathname.split('/').filter(Boolean);
      if (parts.length >= 3 && parts[1] === 'jobs') {
        return { detected: true, platform: 'greenhouse' };
      }
    }

    // Lever: jobs.lever.co + /*/*  path pattern
    if (hostname === 'jobs.lever.co') {
      const parts = pathname.split('/').filter(Boolean);
      if (parts.length >= 2) {
        return { detected: true, platform: 'lever' };
      }
    }

    // Workday: *.myworkdayjobs.com
    if (hostname.endsWith('.myworkdayjobs.com')) {
      return { detected: true, platform: 'workday' };
    }

    // iCIMS: *.icims.com + /jobs/ in path
    if (hostname.endsWith('.icims.com') && pathname.includes('/jobs/')) {
      return { detected: true, platform: 'icims' };
    }

    return { detected: false, platform: null };
  }
}

// ── Tab update listener ──────────────────────────────────────────────────────

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url) return;
  handleTabUpdate(tabId, tab.url);
});

/**
 * Delegates to Job_Detector logic (implemented in task 3.2).
 * Sets badge active/inactive based on detection result.
 * @param {number} tabId
 * @param {string} url
 */
function handleTabUpdate(tabId, url) {
  try {
    const { detected } = new JobDetector().detect(url);
    if (detected) {
      chrome.action.setBadgeText({ text: 'ON', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e', tabId });
    } else {
      chrome.action.setBadgeText({ text: '', tabId });
    }
  } catch (err) {
    console.error('[Job_Detector] DOM parse error:', err);
    chrome.action.setBadgeText({ text: '', tabId });
  }
}

// ── Message handler ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'DETECT_JOB':
      handleDetectJob(message, sendResponse);
      break;
    case 'API_REQUEST':
      handleApiRequest(message, sendResponse);
      break;
    case 'GET_AUTH_STATE':
      handleGetAuthState(sendResponse);
      break;
    case 'REFRESH_TOKEN':
      handleRefreshToken(sendResponse);
      break;
    case 'UPLOAD_RESUME':
      handleUploadResume(message, sendResponse);
      break;
    case 'GENERATE_COVER_LETTER':
      handleGenerateCoverLetter(message, sendResponse);
      break;
    case 'GENERATE_ANSWERS':
      handleGenerateAnswers(message, sendResponse);
      break;
    case 'MARK_AS_APPLIED':
      handleMarkAsApplied(message, sendResponse);
      break;
    default:
      sendResponse({ error: `Unknown message type: ${message.type}` });
  }
  // Return true to keep the message channel open for async responses
  return true;
});

// ── Message handlers (stubs) ─────────────────────────────────────────────────

/**
 * { type: "DETECT_JOB", tabId, url } → { detected: bool, platform }
 */
function handleDetectJob({ tabId, url }, sendResponse) {
  const { detected, platform } = new JobDetector().detect(url);
  sendResponse({ detected, platform });
}

/**
 * { type: "API_REQUEST", endpoint, method, body } → { data, error, status }
 * TODO (task 2.7 / 5.x): add auth header and forward to backend
 */
async function handleApiRequest({ endpoint, method = 'GET', body }, sendResponse) {
  try {
    const { accessToken } = await getStoredTokens();
    const response = await fetch(endpoint, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await response.json();
    sendResponse({ data, error: null, status: response.status });
  } catch (err) {
    sendResponse({ data: null, error: err.message, status: 0 });
  }
}

/**
 * { type: "GET_AUTH_STATE" } → { user, accessToken, tier }
 * TODO (task 2.x): populate from chrome.storage.local
 */
async function handleGetAuthState(sendResponse) {
  const tokens = await getStoredTokens();
  sendResponse({ user: null, accessToken: tokens.accessToken ?? null, tier: 'free' });
}

/**
 * { type: "REFRESH_TOKEN" } → { accessToken } | { error }
 * TODO (task 2.3): call POST /auth/refresh and store new token
 */
async function handleRefreshToken(sendResponse) {
  sendResponse({ error: 'Not implemented yet' });
}

/**
 * { type: "UPLOAD_RESUME", fileData, filename, mimetype } → { data, error, status }
 * Decodes base64 data URL and POSTs the file to POST /resumes.
 */
async function handleUploadResume({ fileData, filename, mimetype }, sendResponse) {
  try {
    const { accessToken } = await getStoredTokens();

    // Decode base64 data URL (e.g. "data:application/pdf;base64,<data>") to binary
    const base64 = fileData.split(',')[1];
    const binaryStr = atob(base64);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) {
      bytes[i] = binaryStr.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: mimetype });

    const formData = new FormData();
    formData.append('resume', blob, filename);

    const BASE_URL = 'http://localhost:3000';
    const response = await fetch(`${BASE_URL}/resumes`, {
      method: 'POST',
      headers: {
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      },
      body: formData,
    });

    const data = await response.json();
    sendResponse({ data, error: null, status: response.status });
  } catch (err) {
    sendResponse({ data: null, error: err.message, status: 0 });
  }
}

/**
 * { type: "GENERATE_COVER_LETTER", jobDescriptionId, resumeId } → { data: { coverLetterText }, error, status }
 */
async function handleGenerateCoverLetter({ jobDescriptionId, resumeId }, sendResponse) {
  try {
    const { accessToken } = await getStoredTokens();
    const BASE_URL = 'http://localhost:3000';
    const response = await fetch(`${BASE_URL}/generate/cover-letter`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      },
      body: JSON.stringify({ jobDescriptionId, resumeId }),
    });
    const data = await response.json();
    sendResponse({ data: data.data, error: data.error, status: response.status });
  } catch (err) {
    sendResponse({ data: null, error: err.message, status: 0 });
  }
}

/**
 * { type: "GENERATE_ANSWERS", jobDescriptionId, resumeId, questions } → { data: { answers: Array<{ question, answer }> }, error, status }
 */
async function handleGenerateAnswers({ jobDescriptionId, resumeId, questions }, sendResponse) {
  try {
    const { accessToken } = await getStoredTokens();
    const BASE_URL = 'http://localhost:3000';
    const response = await fetch(`${BASE_URL}/generate/answers`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      },
      body: JSON.stringify({ jobDescriptionId, resumeId, questions }),
    });
    const data = await response.json();
    sendResponse({ data: data.data, error: data.error, status: response.status });
  } catch (err) {
    sendResponse({ data: null, error: err.message, status: 0 });
  }
}

/**
 * { type: "MARK_AS_APPLIED", jobDescriptionId, matchScore, coverLetterText } → { data, error, status }
 */
async function handleMarkAsApplied({ jobDescriptionId, matchScore, coverLetterText }, sendResponse) {
  try {
    const { accessToken } = await getStoredTokens();
    const BASE_URL = 'http://localhost:3000';
    const response = await fetch(`${BASE_URL}/applications`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      },
      body: JSON.stringify({ jobDescriptionId, matchScore: matchScore ?? null, coverLetterText: coverLetterText ?? null }),
    });
    const data = await response.json();
    sendResponse({ data: data.data, error: data.error, status: response.status });
  } catch (err) {
    sendResponse({ data: null, error: err.message, status: 0 });
  }
}

// ── Token storage helpers ────────────────────────────────────────────────────

/**
 * Retrieves stored auth tokens from chrome.storage.local.
 * @returns {Promise<{ accessToken?: string, refreshToken?: string }>}
 */
function getStoredTokens() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['accessToken', 'refreshToken'], resolve);
  });
}
